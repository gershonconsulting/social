const ORIGIN = "https://social.gershoncrm.com";
const SETTLE_MS = 4000;

const installedVersion = chrome.runtime.getManifest().version;
const verEl = document.getElementById("ver");
const updateBanner = document.getElementById("update-banner");
const statusEl = document.getElementById("status");
const lastEl = document.getElementById("last-captured");

verEl.textContent = "v" + installedVersion;

function show(msg, kind) {
  statusEl.innerHTML = '<div class="status ' + kind + '">' + msg + '</div>';
}

function relTime(ts) {
  if (!ts) return "—";
  const diff = Date.now() - ts;
  const m = Math.round(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return m + "m ago";
  const h = Math.round(m / 60);
  if (h < 24) return h + "h ago";
  return Math.round(h / 24) + "d ago";
}

function semverLt(a, b) {
  const pa = a.split(".").map(function (n) { return parseInt(n, 10) || 0; });
  const pb = b.split(".").map(function (n) { return parseInt(n, 10) || 0; });
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) < (pb[i] || 0)) return true;
    if ((pa[i] || 0) > (pb[i] || 0)) return false;
  }
  return false;
}

async function checkVersion() {
  try {
    const r = await fetch(ORIGIN + "/api/extension/version", { cache: "no-store" });
    if (!r.ok) return;
    const j = await r.json();
    if (!j || !j.success) return;
    if (semverLt(installedVersion, j.data.latest)) {
      updateBanner.innerHTML =
        '<div class="update-banner"><strong>Update available — v' + j.data.latest + '.</strong><br>' +
        (j.data.releaseNotes || "") + "<br>" +
        (j.data.updateInstructions || "Reload the extension in chrome://extensions/.") +
        "</div>";
    }
  } catch (e) {}
}

async function renderLast() {
  const r = await chrome.storage.local.get("lastCapture");
  const last = r.lastCapture || {};
  const parts = [];
  if (last.LINKEDIN) parts.push("<strong>LinkedIn</strong>: " + relTime(last.LINKEDIN.at));
  if (last.TWITTER) parts.push("<strong>X</strong>: " + relTime(last.TWITTER.at));
  lastEl.innerHTML = parts.length ? "Last refresh — " + parts.join(" · ") : "";
}

const PLATFORMS = [
  { name: "LINKEDIN", label: "LinkedIn", url: "https://www.linkedin.com/feed/", domain: "linkedin.com", required: "li_at", names: ["li_at", "JSESSIONID", "liap", "lidc", "bcookie"] },
  { name: "TWITTER",  label: "X",        url: "https://x.com/home",             domain: "x.com",        required: "auth_token", names: ["auth_token", "ct0", "twid", "kdt"] }
];

async function captureOne(p) {
  const tab = await chrome.tabs.create({ url: p.url, active: false });
  await new Promise(function (r) { setTimeout(r, SETTLE_MS); });
  const cookies = {};
  for (const name of p.names) {
    try {
      const cs = await chrome.cookies.getAll({ domain: p.domain, name: name });
      if (cs && cs.length > 0) {
        cs.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
        cookies[name] = cs[0].value;
      }
    } catch (e) {}
  }
  // Keep the tab around so we can re-use it for scraping. Caller decides when to close.
  if (!cookies[p.required]) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: "not logged in to " + p.label, tabId: null };
  }
  let resp;
  try {
    resp = await fetch(ORIGIN + "/api/cookies/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: p.name, cookies: cookies, capturedAt: new Date().toISOString() })
    });
  } catch (e) {
    try { await chrome.tabs.remove(tab.id); } catch (e2) {}
    return { ok: false, error: "network: " + String(e).slice(0, 40), tabId: null };
  }
  if (!resp.ok) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: "server " + resp.status, tabId: null };
  }
  let j = null;
  try { j = await resp.json(); } catch (e) {}
  if (!j || !j.success) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: (j && j.error) || "rejected", tabId: null };
  }
  const r = await chrome.storage.local.get("lastCapture");
  const lastCapture = r.lastCapture || {};
  lastCapture[p.name] = { at: Date.now(), cookieCount: Object.keys(cookies).length };
  await chrome.storage.local.set({ lastCapture: lastCapture });
  return { ok: true, cookieCount: Object.keys(cookies).length, tabId: tab.id };
}

async function fetchClients() {
  const r = await fetch(ORIGIN + "/api/extension/clients", { cache: "no-store" });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data.clients || [];
}

// ====================== LinkedIn scraper (runs in linkedin.com tab) =====================
// IMPORTANT: This function is SERIALIZED + sent to the page. It cannot close over outer
// variables. It uses only its arguments + browser globals.
function linkedinScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const csrf = getCookie("JSESSIONID").replace(/"/g, "");
    const headers = {
      "csrf-token": csrf,
      "Accept": "application/vnd.linkedin.normalized+json+2.1",
      "x-restli-protocol-version": "2.0.0",
      "x-li-lang": "en_US"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.linkedin.connectionId, platform: "LINKEDIN", posts: [] };
      try {
        const uRes = await fetch(
          "/voyager/api/organization/companies?q=universalName&universalName=" + encodeURIComponent(c.linkedin.vanity),
          { headers: headers, credentials: "include", redirect: "manual" }
        );
        if (!uRes.ok) { r.error = "company-lookup HTTP " + uRes.status; results.push(r); continue; }
        let uJson;
        try { uJson = await uRes.json(); } catch (e) { r.error = "company-lookup body not JSON"; results.push(r); continue; }
        const urnRaw = (uJson.elements && uJson.elements[0] && uJson.elements[0].entityUrn) || "";
        if (!urnRaw) { r.error = "company not found"; results.push(r); continue; }
        const orgId = urnRaw.replace(/^urn:li:company:/, "");

        const feedUrl =
          "/voyager/api/feed/updates" +
          "?count=25" +
          "&moduleKey=organization-shares" +
          "&q=organizationShareFeed" +
          "&organizationalPage=" + encodeURIComponent("urn:li:fs_organization:" + orgId);
        const fRes = await fetch(feedUrl, { headers: headers, credentials: "include", redirect: "manual" });
        if (!fRes.ok) { r.error = "feed HTTP " + fRes.status; results.push(r); continue; }
        let fJson;
        try { fJson = await fRes.json(); } catch (e) { r.error = "feed body not JSON"; results.push(r); continue; }

        const elements = fJson.elements || [];
        for (const e of elements) {
          try {
            const urn = (e.updateMetadata && e.updateMetadata.urn) || "";
            if (!urn) continue;
            const m = urn.match(/activity[:-](\d{10,})/);
            const activityId = m ? m[1] : urn;
            const text = (e.commentary && e.commentary.text && e.commentary.text.text) || "";
            if (!text) continue;
            const counts = (e.socialDetail && e.socialDetail.totalSocialActivityCounts) || {};
            r.posts.push({
              externalPostId: activityId,
              postUrl: "https://www.linkedin.com/feed/update/urn:li:activity:" + activityId + "/",
              postTextSnippet: text.slice(0, 280),
              hasMedia: !!e.content,
              publishedAtUtc: new Date().toISOString(),
              likeCount: Number(counts.numLikes || 0),
              commentCount: Number(counts.numComments || 0),
              shareCount: Number(counts.numShares || 0),
              rawPayload: null
            });
          } catch (ee) {}
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

// ====================== X (Twitter) scraper (runs in x.com tab) =====================
function twitterScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const ct0 = getCookie("ct0");
    const BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
    const headers = {
      "Authorization": "Bearer " + BEARER,
      "x-csrf-token": ct0,
      "x-twitter-active-user": "yes",
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-client-language": "en"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.twitter.connectionId, platform: "TWITTER", posts: [] };
      try {
        const url =
          "/i/api/1.1/statuses/user_timeline.json" +
          "?screen_name=" + encodeURIComponent(c.twitter.handle) +
          "&count=50&include_rts=false&tweet_mode=extended";
        const tRes = await fetch(url, { headers: headers, credentials: "include", redirect: "manual" });
        if (!tRes.ok) {
          // Fall back to GraphQL UserByScreenName + UserTweets if v1.1 is gone.
          // Get x-guest-token + manifest hash is fragile; for now record error.
          r.error = "user_timeline HTTP " + tRes.status;
          results.push(r);
          continue;
        }
        let tweets;
        try { tweets = await tRes.json(); } catch (e) { r.error = "body not JSON"; results.push(r); continue; }
        if (!Array.isArray(tweets)) {
          r.error = "non-array response (likely auth/anti-bot)";
          results.push(r);
          continue;
        }
        for (const t of tweets) {
          if (!t.id_str) continue;
          const text = t.full_text || t.text || "";
          const hasMedia = !!(t.entities && t.entities.media && t.entities.media.length);
          r.posts.push({
            externalPostId: t.id_str,
            postUrl: "https://x.com/" + c.twitter.handle + "/status/" + t.id_str,
            postTextSnippet: text.slice(0, 280),
            hasMedia: hasMedia,
            publishedAtUtc: t.created_at ? new Date(t.created_at).toISOString() : new Date().toISOString(),
            likeCount: Number(t.favorite_count || 0),
            commentCount: Number(t.reply_count || 0),
            shareCount: Number(t.retweet_count || 0),
            viewCount: 0,
            rawPayload: null
          });
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

async function scrapeInTab(tabId, scrapeFunc, clients) {
  try {
    const exec = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: scrapeFunc,
      args: [clients]
    });
    return (exec && exec[0] && exec[0].result) || [];
  } catch (e) {
    return clients.map(function (c) {
      return {
        clientId: c.id,
        connectionId: (c.linkedin && c.linkedin.connectionId) || (c.twitter && c.twitter.connectionId) || "?",
        platform: c.linkedin ? "LINKEDIN" : "TWITTER",
        posts: [],
        error: "executeScript: " + ((e && e.message) || String(e)).slice(0, 120)
      };
    });
  }
}

async function ingest(results) {
  if (!results.length) return { totalUpserted: 0, totalAttempts: 0, failed: 0 };
  const r = await fetch(ORIGIN + "/api/extension/ingest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ results: results })
  });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data || { totalUpserted: 0, totalAttempts: 0, failed: 0 };
}

document.getElementById("sync-now").addEventListener("click", async function (e) {
  const btn = e.currentTarget || document.getElementById("sync-now");
  btn.disabled = true;

  // ─── Step 1: capture cookies (opens LinkedIn + X tabs, keeps them open for scraping) ───
  show("Opening LinkedIn + X to capture sessions…", "info");
  const captureResults = {};
  for (const p of PLATFORMS) {
    show("Capturing " + p.label + " session…", "info");
    const cr = await captureOne(p);
    captureResults[p.name] = cr;
  }
  const goodPlatforms = Object.keys(captureResults).filter(function (k) { return captureResults[k].ok; });
  const badPlatforms  = Object.keys(captureResults).filter(function (k) { return !captureResults[k].ok; });
  if (goodPlatforms.length === 0) {
    show("Cookie capture failed: " + badPlatforms.map(function (k) {
      return k + " (" + captureResults[k].error + ")";
    }).join(" · "), "err");
    btn.disabled = false;
    renderLast();
    return;
  }

  // ─── Step 2: fetch client list ───
  show("Fetching client list…", "info");
  let clients;
  try {
    clients = await fetchClients();
  } catch (e2) {
    show("Couldn't load clients: " + ((e2 && e2.message) || e2), "err");
    // close any open scrape tabs
    for (const k of goodPlatforms) {
      const tid = captureResults[k].tabId;
      if (tid) { try { await chrome.tabs.remove(tid); } catch (ee) {} }
    }
    btn.disabled = false;
    renderLast();
    return;
  }

  const liClients = (captureResults.LINKEDIN && captureResults.LINKEDIN.ok)
    ? clients.filter(function (c) { return !!c.linkedin; })
    : [];
  const twClients = (captureResults.TWITTER && captureResults.TWITTER.ok)
    ? clients.filter(function (c) { return !!c.twitter; })
    : [];

  let totalUpserted = 0;
  let totalFailed = 0;
  const ingestErrors = [];

  // ─── Step 3: LinkedIn scrape (inside the LinkedIn tab we already opened) ───
  if (liClients.length && captureResults.LINKEDIN.tabId) {
    show("Scraping LinkedIn in your browser · " + liClients.length + " companies…", "info");
    const liResults = await scrapeInTab(captureResults.LINKEDIN.tabId, linkedinScrapeIIFE, liClients);
    try {
      const out = await ingest(liResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
      show("LinkedIn done: " + (out.totalUpserted || 0) + " posts upserted. Scraping X…", "info");
    } catch (e3) {
      ingestErrors.push("LinkedIn: " + ((e3 && e3.message) || e3));
    }
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  } else if (captureResults.LINKEDIN && captureResults.LINKEDIN.tabId) {
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  }

  // ─── Step 4: X scrape (inside the X tab we already opened) ───
  if (twClients.length && captureResults.TWITTER.tabId) {
    show("Scraping X in your browser · " + twClients.length + " accounts…", "info");
    const twResults = await scrapeInTab(captureResults.TWITTER.tabId, twitterScrapeIIFE, twClients);
    try {
      const out = await ingest(twResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
    } catch (e4) {
      ingestErrors.push("X: " + ((e4 && e4.message) || e4));
    }
    try { await chrome.tabs.remove(captureResults.TWITTER.tabId); } catch (ee) {}
  } else if (captureResults.TWITTER && captureResults.TWITTER.tabId) {
    try { await chrome.tabs.remove(captureResults.TWITTER.tabId); } catch (ee) {}
  }

  btn.disabled = false;

  // ─── Final status ───
  const accountCount = liClients.length + twClients.length;
  let msg = "✓ " + totalUpserted + " posts upserted across " + accountCount + " accounts";
  if (totalFailed > 0) msg += " · " + totalFailed + " failed";
  if (badPlatforms.length > 0) msg += " · cookie issues: " + badPlatforms.join(", ");
  if (ingestErrors.length > 0) msg += " · ingest errors: " + ingestErrors.join(", ");
  show(msg, totalUpserted > 0 ? "ok" : "err");
  renderLast();
});

renderLast();
checkVersion();
