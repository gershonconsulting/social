const ORIGIN = "https://social.gershoncrm.com";
const SETTLE_MS = 3500;

const installedVersion = chrome.runtime.getManifest().version;
const verEl = document.getElementById("ver");
const updateBanner = document.getElementById("update-banner");
const statusEl = document.getElementById("status");
const lastEl = document.getElementById("last-captured");

verEl.textContent = "v" + installedVersion;

function show(msg, kind) {
  statusEl.innerHTML = '<div class="status ' + kind + '">' + msg + '</div>';
}

function relTime(ts) {
  if (!ts) return "—";
  const diff = Date.now() - ts;
  const m = Math.round(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return m + "m ago";
  const h = Math.round(m / 60);
  if (h < 24) return h + "h ago";
  return Math.round(h / 24) + "d ago";
}

function semverLt(a, b) {
  const pa = a.split(".").map(function (n) { return parseInt(n, 10) || 0; });
  const pb = b.split(".").map(function (n) { return parseInt(n, 10) || 0; });
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i]||0) < (pb[i]||0)) return true;
    if ((pa[i]||0) > (pb[i]||0)) return false;
  }
  return false;
}

async function checkVersion() {
  try {
    const r = await fetch(ORIGIN + "/api/extension/version", { cache: "no-store" });
    if (!r.ok) return;
    const j = await r.json();
    if (!j || !j.success) return;
    if (semverLt(installedVersion, j.data.latest)) {
      updateBanner.innerHTML =
        '<div class="update-banner"><strong>Update available — v' + j.data.latest + '.</strong><br>' +
        (j.data.releaseNotes || "") + "<br>" +
        (j.data.updateInstructions || "Reload the extension in chrome://extensions/.") +
        "</div>";
    }
  } catch (e) {}
}

async function renderLast() {
  const r = await chrome.storage.local.get("lastCapture");
  const last = r.lastCapture || {};
  const parts = [];
  if (last.LINKEDIN) parts.push("<strong>LinkedIn</strong>: " + relTime(last.LINKEDIN.at));
  if (last.TWITTER) parts.push("<strong>X</strong>: " + relTime(last.TWITTER.at));
  lastEl.innerHTML = parts.length ? "Last refresh — " + parts.join(" · ") : "";
}

const PLATFORMS = [
  { name: "LINKEDIN", label: "LinkedIn", url: "https://www.linkedin.com/feed/", domain: "linkedin.com", required: "li_at", names: ["li_at", "JSESSIONID", "liap", "lidc", "bcookie"] },
  { name: "TWITTER",  label: "X",        url: "https://x.com/home",             domain: "x.com",        required: "auth_token", names: ["auth_token", "ct0", "twid", "kdt"] }
];

async function captureOne(p) {
  const tab = await chrome.tabs.create({ url: p.url, active: false });
  await new Promise(function (r) { setTimeout(r, SETTLE_MS); });
  const cookies = {};
  for (const name of p.names) {
    try {
      const cs = await chrome.cookies.getAll({ domain: p.domain, name: name });
      if (cs && cs.length > 0) {
        cs.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
        cookies[name] = cs[0].value;
      }
    } catch (e) {}
  }
  try { await chrome.tabs.remove(tab.id); } catch (e) {}
  if (!cookies[p.required]) return { ok: false, error: "not logged in to " + p.label };
  let resp;
  try {
    resp = await fetch(ORIGIN + "/api/cookies/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: p.name, cookies: cookies, capturedAt: new Date().toISOString() })
    });
  } catch (e) { return { ok: false, error: "network: " + String(e).slice(0, 40) }; }
  if (!resp.ok) return { ok: false, error: "server " + resp.status };
  let j = null;
  try { j = await resp.json(); } catch (e) {}
  if (!j || !j.success) return { ok: false, error: (j && j.error) || "rejected" };
  const r = await chrome.storage.local.get("lastCapture");
  const lastCapture = r.lastCapture || {};
  lastCapture[p.name] = { at: Date.now(), cookieCount: Object.keys(cookies).length };
  await chrome.storage.local.set({ lastCapture: lastCapture });
  return { ok: true, cookieCount: Object.keys(cookies).length };
}

// Loop through chunks of /api/cron/scrape-all-clients until hasMore=false.
// Each call processes ~5 clients; 27 clients => 6 chunks => completes in ~30s.
async function triggerServerScrapeAll() {
  let offset = 0;
  let totalUpserted = 0;
  let totalAttempts = 0;
  let totalFailed = 0;
  let totalClients = 0;
  const maxChunks = 20; // safety
  for (let i = 0; i < maxChunks; i++) {
    let r;
    try {
      r = await fetch(ORIGIN + "/api/cron/scrape-all-clients?offset=" + offset + "&limit=5", { cache: "no-store" });
    } catch (e) {
      return { ok: false, error: "network: " + String(e).slice(0, 50), totalUpserted, totalAttempts, totalFailed };
    }
    if (!r.ok) return { ok: false, error: "server " + r.status, totalUpserted, totalAttempts, totalFailed };
    let j = null;
    try { j = await r.json(); } catch (e) {}
    if (!j || !j.success) return { ok: false, error: (j && j.error) || "rejected", totalUpserted, totalAttempts, totalFailed };
    totalUpserted += j.data.totalUpserted || 0;
    totalAttempts += j.data.totalAttempts || 0;
    totalFailed += j.data.failed || 0;
    totalClients = j.data.totalClients || totalClients;
    show("Scraping clients… " + Math.min(offset + 5, totalClients) + " / " + totalClients + " · " + totalUpserted + " posts so far", "info");
    if (!j.data.hasMore || j.data.nextOffset == null) break;
    offset = j.data.nextOffset;
  }
  return { ok: true, totalUpserted, totalAttempts, totalFailed, totalClients };
}

document.getElementById("sync-now").addEventListener("click", async function (e) {
  // Cache the button before any await — Chrome zeroes out e.currentTarget
  // after the dispatch completes, so accessing it post-await throws null.
  const btn = e.currentTarget || document.getElementById("sync-now");
  btn.disabled = true;
  show("Capturing cookies — opening LinkedIn + X…", "info");
  const results = [];
  for (const p of PLATFORMS) {
    show("Opening " + p.label + "…", "info");
    const r = await captureOne(p);
    results.push({ platform: p.label, ...r });
  }
  const goods = results.filter(function (r) { return r.ok; });
  const bads = results.filter(function (r) { return !r.ok; });
  if (goods.length === 0) {
    show("Capture failed: " + bads.map(function (r) { return r.platform + " (" + r.error + ")"; }).join(" · "), "err");
    btn.disabled = false;
    renderLast();
    return;
  }
  show("Cookies sent. Starting full scrape across all clients…", "info");
  const scrape = await triggerServerScrapeAll();
  btn.disabled = false;
  if (scrape.ok) {
    let msg = "✓ " + scrape.totalUpserted + " posts upserted across " + scrape.totalClients + " clients (attempts: " + scrape.totalAttempts + ")";
    if (scrape.totalFailed > 0) msg += " · " + scrape.totalFailed + " failed";
    if (bads.length > 0) msg += " · cookie issues: " + bads.map(function (r) { return r.platform; }).join(", ");
    show(msg, scrape.totalUpserted > 0 || bads.length === 0 ? "ok" : "err");
  } else {
    show("Scrape stopped: " + scrape.error + " (so far: " + scrape.totalUpserted + " posts)", "err");
  }
  renderLast();
});

renderLast();
checkVersion();
