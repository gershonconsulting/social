# GershonAI — Chrome extension (cookie capture)

One-click capture of your LinkedIn and X session cookies into social.gershoncrm.com. After capture, immediately triggers the server-side scrape so fresh posts arrive in the dashboard.

## Install (one-time)

1. Open `chrome://extensions/`
2. Toggle **Developer mode** (top-right)
3. Click **Load unpacked** → pick the folder:
   ```
   C:\Users\oatti\Documents\Claude\Projects\Social Gershon Consulting\watchman-chrome-extension
   ```
4. Pin the icon (puzzle-piece menu → pin **GershonAI**).

## Use

- Make sure you're logged in to LinkedIn and X in this Chrome profile.
- Click the GershonAI icon → **Sync Now**.
- It opens LinkedIn and X in background tabs, captures cookies, sends them to the dashboard, then triggers a server-side scrape.
- Green toast = done. Red toast = something wrong (most often: not logged in to one of the platforms).

## Updates

When I publish a new version, the popup shows an amber "Update available — vX.Y" banner the next time you open it. Reload via `chrome://extensions/` → reload icon on the GershonAI card.
