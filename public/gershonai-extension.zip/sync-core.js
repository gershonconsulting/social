// Shared sync core — runs from popup AND from background alarm.
// Loaded into popup.html via <script> and into background.js via importScripts.

const SETTLE_MS = 4000;

const PLATFORMS = [
  { name: "LINKEDIN", label: "LinkedIn", url: "https://www.linkedin.com/feed/", domains: ["linkedin.com"], required: "li_at", names: ["li_at", "JSESSIONID", "liap", "lidc", "bcookie"] },
  // X / Twitter rebranded but legacy cookies often still live under
  // the .twitter.com domain. Chrome's chrome.cookies.getAll({domain:"x.com"})
  // matches x.com + subdomains only, NOT the sibling twitter.com domain.
  // So we explicitly try BOTH and take whichever has auth_token.
  { name: "TWITTER",  label: "X",        url: "https://x.com/home",             domains: ["x.com", "twitter.com"], required: "auth_token", names: ["auth_token", "ct0", "twid", "kdt"] }
];

async function captureOne(p, origin) {
  const tab = await chrome.tabs.create({ url: p.url, active: false });
  // Twitter's home in a background tab needs longer to settle + replay any
  // refresh-auth flow. LinkedIn is fine with 4s.
  const settleMs = p.name === "TWITTER" ? 7000 : SETTLE_MS;
  await new Promise(function (r) { setTimeout(r, settleMs); });
  const cookies = {};
  const domains = p.domains || [p.domain];
  for (const name of p.names) {
    let best = null;
    // Try each candidate domain. chrome.cookies.getAll matches `domain`
    // and its subdomains only, so we have to query x.com and twitter.com
    // separately rather than relying on a single wildcard.
    for (const domain of domains) {
      try {
        const cs = await chrome.cookies.getAll({ domain: domain, name: name });
        if (cs && cs.length > 0) {
          cs.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
          if (!best || (cs[0].expirationDate || 0) > (best.expirationDate || 0)) {
            best = cs[0];
          }
        }
      } catch (e) {}
    }
    // Last-resort fallback: no-domain lookup. Returns cookies whose name
    // matches across the whole cookie store; we pick the longest-lived.
    if (!best) {
      try {
        const cs = await chrome.cookies.getAll({ name: name });
        const filtered = (cs || []).filter(function (c) {
          // Only accept cookies whose domain matches one of our candidates
          // (or a subdomain). Avoids accidentally picking up cookies set
          // by unrelated sites with the same name.
          const d = (c.domain || "").replace(/^\./, "");
          return domains.some(function (cd) { return d === cd || d.endsWith("." + cd); });
        });
        filtered.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
        if (filtered.length > 0) best = filtered[0];
      } catch (e) {}
    }
    if (best) cookies[name] = best.value;
  }
  if (!cookies[p.required]) {
    // v0.10.2: leave the tab open on TWITTER so Olivier can inspect what
    // x.com is actually rendering when auth_token is missing. Logged out?
    // Cookie partitioned? Some interstitial? Now visible.
    if (p.name === "TWITTER") {
      try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
      return { ok: false, error: "not logged in to " + p.label + " — tab left open for inspection", tabId: tab.id };
    }
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: "not logged in to " + p.label, tabId: null };
  }
  let resp;
  try {
    resp = await fetch(origin + "/api/cookies/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: p.name, cookies: cookies, capturedAt: new Date().toISOString() })
    });
  } catch (e) {
    try { await chrome.tabs.remove(tab.id); } catch (e2) {}
    return { ok: false, error: "network: " + String(e).slice(0, 40), tabId: null };
  }
  if (!resp.ok) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: "server " + resp.status, tabId: null };
  }
  let j = null;
  try { j = await resp.json(); } catch (e) {}
  if (!j || !j.success) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: (j && j.error) || "rejected", tabId: null };
  }
  const r = await chrome.storage.local.get("lastCapture");
  const lastCapture = r.lastCapture || {};
  lastCapture[p.name] = { at: Date.now(), cookieCount: Object.keys(cookies).length };
  await chrome.storage.local.set({ lastCapture: lastCapture });
  return { ok: true, cookieCount: Object.keys(cookies).length, tabId: tab.id };
}

async function fetchClients(origin) {
  const r = await fetch(origin + "/api/extension/clients", { cache: "no-store" });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data.clients || [];
}

function linkedinScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const csrf = getCookie("JSESSIONID").replace(/"/g, "");
    const headers = {
      "csrf-token": csrf,
      "Accept": "application/vnd.linkedin.normalized+json+2.1",
      "x-restli-protocol-version": "2.0.0",
      "x-li-lang": "en_US"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.linkedin.connectionId, platform: "LINKEDIN", posts: [] };
      try {
        const uRes = await fetch(
          "/voyager/api/organization/companies?q=universalName&universalName=" + encodeURIComponent(c.linkedin.vanity),
          { headers: headers, credentials: "include", redirect: "manual" }
        );
        if (!uRes.ok) { r.error = "company-lookup HTTP " + uRes.status; results.push(r); continue; }
        let uJson;
        try { uJson = await uRes.json(); } catch (e) { r.error = "company-lookup body not JSON"; results.push(r); continue; }
        const urnRaw = (uJson.elements && uJson.elements[0] && uJson.elements[0].entityUrn) || "";
        if (!urnRaw) { r.error = "company not found"; results.push(r); continue; }
        const orgId = urnRaw.replace(/^urn:li:company:/, "");
        const feedUrl =
          "/voyager/api/feed/updates?count=25&moduleKey=organization-shares&q=organizationShareFeed&organizationalPage=" +
          encodeURIComponent("urn:li:fs_organization:" + orgId);
        const fRes = await fetch(feedUrl, { headers: headers, credentials: "include", redirect: "manual" });
        if (!fRes.ok) { r.error = "feed HTTP " + fRes.status; results.push(r); continue; }
        let fJson;
        try { fJson = await fRes.json(); } catch (e) { r.error = "feed body not JSON"; results.push(r); continue; }
        const elements = fJson.elements || [];
        for (const e of elements) {
          try {
            const urn = (e.updateMetadata && e.updateMetadata.urn) || "";
            if (!urn) continue;
            const m = urn.match(/activity[:-](\d{10,})/);
            const activityId = m ? m[1] : urn;
            const text = (e.commentary && e.commentary.text && e.commentary.text.text) || "";
            if (!text) continue;
            const counts = (e.socialDetail && e.socialDetail.totalSocialActivityCounts) || {};
            r.posts.push({
              externalPostId: activityId,
              postUrl: "https://www.linkedin.com/feed/update/urn:li:activity:" + activityId + "/",
              postTextSnippet: text.slice(0, 280),
              hasMedia: !!e.content,
              publishedAtUtc: new Date().toISOString(),
              likeCount: Number(counts.numLikes || 0),
              commentCount: Number(counts.numComments || 0),
              shareCount: Number(counts.numShares || 0),
              rawPayload: null
            });
          } catch (ee) {}
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

function twitterScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const ct0 = getCookie("ct0");
    const BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
    const headers = {
      "Authorization": "Bearer " + BEARER,
      "x-csrf-token": ct0,
      "x-twitter-active-user": "yes",
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-client-language": "en"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.twitter.connectionId, platform: "TWITTER", posts: [] };
      try {
        const url =
          "/i/api/1.1/statuses/user_timeline.json?screen_name=" + encodeURIComponent(c.twitter.handle) +
          "&count=50&include_rts=false&tweet_mode=extended";
        const tRes = await fetch(url, { headers: headers, credentials: "include", redirect: "manual" });
        if (!tRes.ok) { r.error = "user_timeline HTTP " + tRes.status; results.push(r); continue; }
        let tweets;
        try { tweets = await tRes.json(); } catch (e) { r.error = "body not JSON"; results.push(r); continue; }
        if (!Array.isArray(tweets)) { r.error = "non-array response (likely auth/anti-bot)"; results.push(r); continue; }
        for (const t of tweets) {
          if (!t.id_str) continue;
          const text = t.full_text || t.text || "";
          const hasMedia = !!(t.entities && t.entities.media && t.entities.media.length);
          r.posts.push({
            externalPostId: t.id_str,
            postUrl: "https://x.com/" + c.twitter.handle + "/status/" + t.id_str,
            postTextSnippet: text.slice(0, 280),
            hasMedia: hasMedia,
            publishedAtUtc: t.created_at ? new Date(t.created_at).toISOString() : new Date().toISOString(),
            likeCount: Number(t.favorite_count || 0),
            commentCount: Number(t.reply_count || 0),
            shareCount: Number(t.retweet_count || 0),
            viewCount: 0,
            rawPayload: null
          });
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

async function scrapeInTab(tabId, scrapeFunc, clients) {
  try {
    const exec = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: scrapeFunc,
      args: [clients]
    });
    return (exec && exec[0] && exec[0].result) || [];
  } catch (e) {
    return clients.map(function (c) {
      return {
        clientId: c.id,
        connectionId: (c.linkedin && c.linkedin.connectionId) || (c.twitter && c.twitter.connectionId) || "?",
        platform: c.linkedin ? "LINKEDIN" : "TWITTER",
        posts: [],
        error: "executeScript: " + ((e && e.message) || String(e)).slice(0, 120)
      };
    });
  }
}

async function ingest(origin, results) {
  if (!results.length) return { totalUpserted: 0, totalAttempts: 0, failed: 0 };
  const r = await fetch(origin + "/api/extension/ingest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ results: results, source: "extension-v0.10" })
  });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data || { totalUpserted: 0, totalAttempts: 0, failed: 0 };
}

async function runFullSync(opts) {
  const origin = (opts && opts.origin) || "https://social.gershoncrm.com";
  const onProgress = (opts && opts.onProgress) || function () {};

  onProgress("Opening LinkedIn + X to capture sessions…", "info");
  const captureResults = {};
  for (const p of PLATFORMS) {
    onProgress("Capturing " + p.label + " session…", "info");
    captureResults[p.name] = await captureOne(p, origin);
  }
  const goodPlatforms = Object.keys(captureResults).filter(function (k) { return captureResults[k].ok; });
  const badPlatforms  = Object.keys(captureResults).filter(function (k) { return !captureResults[k].ok; });
  if (goodPlatforms.length === 0) {
    return { ok: false, totalUpserted: 0, totalFailed: 0, accountCount: 0, badPlatforms: badPlatforms, ingestErrors: ["all cookie captures failed"] };
  }

  onProgress("Fetching client list…", "info");
  let clients;
  try {
    clients = await fetchClients(origin);
  } catch (e2) {
    for (const k of goodPlatforms) {
      const tid = captureResults[k].tabId;
      if (tid) { try { await chrome.tabs.remove(tid); } catch (ee) {} }
    }
    return { ok: false, totalUpserted: 0, totalFailed: 0, accountCount: 0, badPlatforms: badPlatforms, ingestErrors: ["client-fetch: " + ((e2 && e2.message) || e2)] };
  }

  const liClients = (captureResults.LINKEDIN && captureResults.LINKEDIN.ok)
    ? clients.filter(function (c) { return !!c.linkedin; }) : [];
  const twClients = (captureResults.TWITTER && captureResults.TWITTER.ok)
    ? clients.filter(function (c) { return !!c.twitter; }) : [];

  let totalUpserted = 0;
  let totalFailed = 0;
  const ingestErrors = [];

  if (liClients.length && captureResults.LINKEDIN.tabId) {
    onProgress("Scraping LinkedIn in your browser · " + liClients.length + " companies…", "info");
    const liResults = await scrapeInTab(captureResults.LINKEDIN.tabId, linkedinScrapeIIFE, liClients);
    try {
      const out = await ingest(origin, liResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
    } catch (e3) { ingestErrors.push("LinkedIn: " + ((e3 && e3.message) || e3)); }
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  } else if (captureResults.LINKEDIN && captureResults.LINKEDIN.tabId) {
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  }

  if (twClients.length && captureResults.TWITTER.tabId) {
    onProgress("Scraping X in your browser · " + twClients.length + " accounts…", "info");
    const twResults = await scrapeInTab(captureResults.TWITTER.tabId, twitterScrapeIIFE, twClients);
    try {
      const out = await ingest(origin, twResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
    } catch (e4) { ingestErrors.push("X: " + ((e4 && e4.message) || e4)); }
    // v0.10.2: leave the X tab open after scrape so Olivier can inspect
    // it. Activate it so it's in the foreground instead of hiding in the
    // background tab strip.
    try { await chrome.tabs.update(captureResults.TWITTER.tabId, { active: true }); } catch (ee) {}
  } else if (captureResults.TWITTER && captureResults.TWITTER.tabId) {
    try { await chrome.tabs.update(captureResults.TWITTER.tabId, { active: true }); } catch (ee) {}
  }

  await chrome.storage.local.set({
    lastAutoSync: {
      at: Date.now(),
      totalUpserted: totalUpserted,
      totalFailed: totalFailed,
      accountCount: liClients.length + twClients.length,
      badPlatforms: badPlatforms,
      ingestErrors: ingestErrors
    }
  });

  return {
    ok: true,
    totalUpserted: totalUpserted,
    totalFailed: totalFailed,
    accountCount: liClients.length + twClients.length,
    badPlatforms: badPlatforms,
    ingestErrors: ingestErrors
  };
}

if (typeof self !== "undefined") { self.runFullSync = runFullSync; }
if (typeof window !== "undefined") { window.runFullSync = runFullSync; }
