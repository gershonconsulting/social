// Shared sync core — runs from popup AND from background alarm.
// Loaded into popup.html via <script> and into background.js via importScripts.

const SETTLE_MS = 4000;

const PLATFORMS = [
  { name: "LINKEDIN", label: "LinkedIn", url: "https://www.linkedin.com/feed/", domains: ["linkedin.com", "www.linkedin.com", "fr.linkedin.com"], required: "li_at", names: ["li_at", "JSESSIONID", "liap", "lidc", "bcookie"] },
  // X / Twitter rebranded but legacy cookies often still live under
  // the .twitter.com domain. Chrome's chrome.cookies.getAll({domain:"x.com"})
  // matches x.com + subdomains only, NOT the sibling twitter.com domain.
  // So we explicitly try BOTH and take whichever has auth_token.
  { name: "TWITTER",  label: "X",        url: "https://x.com/home",             domains: ["x.com", "twitter.com"], required: "auth_token", names: ["auth_token", "ct0", "twid", "kdt"] }
];


// v0.10.6: When the LinkedIn capture fails because we have no li_at cookie,
// attempt to recover by driving the login wall ourselves. LinkedIn's
// logged-out home shows a "Sign in as <user>" button (the saved-account
// card) that takes us to a pre-filled password page where Chrome's
// password autofill fills the password automatically. We click that
// button, wait, then submit the form, wait again, and let the caller
// re-read cookies.
async function attemptLinkedInAutoLogin(tabId, runLog) {
  runLog.push({ at: Date.now(), step: "LINKEDIN:auto-reauth-start" });

  // Step A: foreground the tab — Chrome will NOT fire password autofill on
  // a background tab. Has to be active for chrome.passwordManager to inject.
  try { await chrome.tabs.update(tabId, { active: true }); } catch (e) {}
  await new Promise(function (r) { setTimeout(r, 2500); });

  // Step B: snapshot the current URL/text so the log shows what we saw.
  let landingInfo = null;
  try {
    const probe = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: function () {
        const text = (document.body && document.body.innerText || "").slice(0, 400);
        return { url: location.href, title: document.title, snippet: text.replace(/\s+/g, " ") };
      }
    });
    landingInfo = (probe && probe[0] && probe[0].result) || null;
  } catch (e) {}
  if (landingInfo) runLog.push({ at: Date.now(), step: "LINKEDIN:auto-reauth-landing", detail: landingInfo });

  // Step C: click the saved-account button on the welcome page.
  let stepCClicked = null;
  try {
    const r1 = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: function () {
        function visible(el) {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        }
        // Selectors LinkedIn has used for the saved-account button. Listed
        // in order from most specific to least.
        const queries = [
          'button[data-tracking-control-name*="member_card"]',
          'a[data-tracking-control-name*="member_card"]',
          'button[data-tracking-control-name*="sign-in_signin"]',
          '.member-profile-block button',
          '.member-profile-block',
          'button.profile-card__sign-in-form-button',
        ];
        for (const q of queries) {
          const els = Array.from(document.querySelectorAll(q)).filter(visible);
          if (els.length) { els[0].click(); return { method: q, text: (els[0].innerText||"").slice(0,80) }; }
        }
        // Fallback: any visible button whose text contains "Sign in as" or
        // an "@" (matches the obfuscated email shown on the card).
        const buttons = Array.from(document.querySelectorAll("button, a")).filter(visible);
        const m = buttons.find(function (b) {
          const t = (b.innerText || b.textContent || "").trim();
          return /sign in as/i.test(t) || /@/.test(t);
        });
        if (m) { m.click(); return { method: "text-match", text: (m.innerText||"").slice(0,80) }; }
        return { method: null };
      }
    });
    stepCClicked = (r1 && r1[0] && r1[0].result) || null;
  } catch (e) {
    stepCClicked = { error: (e && e.message) || String(e) };
  }
  runLog.push({ at: Date.now(), step: "LINKEDIN:auto-reauth-click-account", detail: stepCClicked });

  // Wait for the password page to load.
  await new Promise(function (r) { setTimeout(r, 4500); });

  // Step D: on the password page, focus the input (helps Chrome autofill
  // commit its value) then click the submit button. If Chrome's saved
  // password is present, this completes the login. If not, the page just
  // sits there and the next cookie check will fail — same as before.
  let stepDSubmit = null;
  try {
    const r2 = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: function () {
        const out = {};
        const pwd = document.querySelector("input[name='session_password'], input#password, input[type='password']");
        if (pwd) {
          try { pwd.focus(); pwd.click(); } catch (_) {}
          out.passwordPrefilled = !!pwd.value;
        } else {
          out.passwordInputFound = false;
        }
        const btn =
          document.querySelector("button[type='submit'][aria-label*='Sign in' i]") ||
          document.querySelector("button[data-litms-control-urn*='login-submit']") ||
          Array.from(document.querySelectorAll("button[type='submit']"))[0] ||
          Array.from(document.querySelectorAll("button")).find(function (b) { return /sign in/i.test(b.innerText); });
        if (btn) { btn.click(); out.submitClicked = true; }
        else {
          const form = document.querySelector("form.login__form, form[action*='login-submit'], form[action*='checkpoint']");
          if (form) { form.submit(); out.formSubmitted = true; }
        }
        return out;
      }
    });
    stepDSubmit = (r2 && r2[0] && r2[0].result) || null;
  } catch (e) {
    stepDSubmit = { error: (e && e.message) || String(e) };
  }
  runLog.push({ at: Date.now(), step: "LINKEDIN:auto-reauth-submit", detail: stepDSubmit });

  // Wait for the post-login redirect back to LinkedIn home.
  await new Promise(function (r) { setTimeout(r, 7000); });

  runLog.push({ at: Date.now(), step: "LINKEDIN:auto-reauth-done" });
}

async function captureOne(p, origin, runLog) {
  runLog.push({ at: Date.now(), step: p.name + ":open-tab", detail: { url: p.url } });
  const tab = await chrome.tabs.create({ url: p.url, active: false });
  // Twitter's home in a background tab needs longer to settle + replay any
  // refresh-auth flow. LinkedIn is fine with 4s.
  const settleMs = 7000;  // both LI and X background tabs need 7s in 2026
  await new Promise(function (r) { setTimeout(r, settleMs); });
  const cookies = {};
  const domains = p.domains || [p.domain];
  for (const name of p.names) {
    let best = null;
    // Try each candidate domain. chrome.cookies.getAll matches `domain`
    // and its subdomains only, so we have to query x.com and twitter.com
    // separately rather than relying on a single wildcard.
    for (const domain of domains) {
      try {
        const cs = await chrome.cookies.getAll({ domain: domain, name: name });
        if (cs && cs.length > 0) {
          cs.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
          if (!best || (cs[0].expirationDate || 0) > (best.expirationDate || 0)) {
            best = cs[0];
          }
        }
      } catch (e) {}
    }
    // Last-resort fallback: no-domain lookup. Returns cookies whose name
    // matches across the whole cookie store; we pick the longest-lived.
    if (!best) {
      try {
        const cs = await chrome.cookies.getAll({ name: name });
        const filtered = (cs || []).filter(function (c) {
          // Only accept cookies whose domain matches one of our candidates
          // (or a subdomain). Avoids accidentally picking up cookies set
          // by unrelated sites with the same name.
          const d = (c.domain || "").replace(/^\./, "");
          return domains.some(function (cd) { return d === cd || d.endsWith("." + cd); });
        });
        filtered.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
        if (filtered.length > 0) best = filtered[0];
      } catch (e) {}
    }
    if (best) cookies[name] = best.value;
  }
  runLog.push({
    at: Date.now(),
    step: p.name + ":cookies-summary",
    detail: {
      domainsChecked: p.domains || [p.domain],
      cookiesFound: Object.keys(cookies),
      cookiesMissing: p.names.filter(function (n) { return !cookies[n]; }),
      requiredCookie: p.required,
      requiredPresent: !!cookies[p.required],
    }
  });
  if (!cookies[p.required]) {
    // v0.10.6: For LinkedIn, attempt auto-reauth by driving the login wall
    // ourselves before giving up. Chrome's password autofill handles the
    // password field; we just have to click through the buttons.
    if (p.name === "LINKEDIN") {
      runLog.push({ at: Date.now(), step: p.name + ":required-missing-attempting-reauth" });
      await attemptLinkedInAutoLogin(tab.id, runLog);
      // Re-read cookies after the auto-reauth attempt.
      for (const name of p.names) {
        if (cookies[name]) continue;
        for (const domain of domains) {
          try {
            const cs2 = await chrome.cookies.getAll({ domain: domain, name: name });
            if (cs2 && cs2.length > 0) {
              cs2.sort(function (a, b) { return (b.expirationDate || 0) - (a.expirationDate || 0); });
              cookies[name] = cs2[0].value;
              break;
            }
          } catch (e) {}
        }
      }
      runLog.push({
        at: Date.now(),
        step: p.name + ":cookies-after-reauth",
        detail: {
          cookiesFound: Object.keys(cookies),
          cookiesMissing: p.names.filter(function (n) { return !cookies[n]; }),
          requiredPresent: !!cookies[p.required],
        }
      });
    }
  }
  if (!cookies[p.required]) {
    runLog.push({ at: Date.now(), step: p.name + ":capture-FAILED", detail: { reason: "required cookie '" + p.required + "' not found in any candidate domain — you may not be logged in to " + p.label + " in this Chrome profile" } });
    // v0.10.4: keep BOTH X and LinkedIn tabs open + foregrounded on capture
    // failure so the user can see what the site is actually rendering.
    try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
    return { ok: false, error: "not logged in to " + p.label + " — tab left open for inspection", tabId: tab.id };
  }
  let resp;
  try {
    resp = await fetch(origin + "/api/cookies/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: p.name, cookies: cookies, capturedAt: new Date().toISOString() })
    });
  } catch (e) {
    try { await chrome.tabs.remove(tab.id); } catch (e2) {}
    return { ok: false, error: "network: " + String(e).slice(0, 40), tabId: null };
  }
  if (!resp.ok) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: "server " + resp.status, tabId: null };
  }
  let j = null;
  try { j = await resp.json(); } catch (e) {}
  if (!j || !j.success) {
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    return { ok: false, error: (j && j.error) || "rejected", tabId: null };
  }
  const r = await chrome.storage.local.get("lastCapture");
  const lastCapture = r.lastCapture || {};
  lastCapture[p.name] = { at: Date.now(), cookieCount: Object.keys(cookies).length };
  await chrome.storage.local.set({ lastCapture: lastCapture });
  runLog.push({ at: Date.now(), step: p.name + ":capture-OK", detail: { cookieCount: Object.keys(cookies).length } });
  return { ok: true, cookieCount: Object.keys(cookies).length, tabId: tab.id };
}

async function fetchClients(origin) {
  const r = await fetch(origin + "/api/extension/clients", { cache: "no-store" });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data.clients || [];
}

function linkedinScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const csrf = getCookie("JSESSIONID").replace(/"/g, "");
    const headers = {
      "csrf-token": csrf,
      "Accept": "application/vnd.linkedin.normalized+json+2.1",
      "x-restli-protocol-version": "2.0.0",
      "x-li-lang": "en_US"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.linkedin.connectionId, platform: "LINKEDIN", posts: [] };
      try {
        const uRes = await fetch(
          "/voyager/api/organization/companies?q=universalName&universalName=" + encodeURIComponent(c.linkedin.vanity),
          { headers: headers, credentials: "include", redirect: "manual" }
        );
        if (!uRes.ok) { r.error = "company-lookup HTTP " + uRes.status; results.push(r); continue; }
        let uJson;
        try { uJson = await uRes.json(); } catch (e) { r.error = "company-lookup body not JSON"; results.push(r); continue; }
        const urnRaw = (uJson.elements && uJson.elements[0] && uJson.elements[0].entityUrn) || "";
        if (!urnRaw) { r.error = "company not found"; results.push(r); continue; }
        const orgId = urnRaw.replace(/^urn:li:company:/, "");
        const feedUrl =
          "/voyager/api/feed/updates?count=25&moduleKey=organization-shares&q=organizationShareFeed&organizationalPage=" +
          encodeURIComponent("urn:li:fs_organization:" + orgId);
        const fRes = await fetch(feedUrl, { headers: headers, credentials: "include", redirect: "manual" });
        if (!fRes.ok) { r.error = "feed HTTP " + fRes.status; results.push(r); continue; }
        let fJson;
        try { fJson = await fRes.json(); } catch (e) { r.error = "feed body not JSON"; results.push(r); continue; }
        const elements = fJson.elements || [];
        for (const e of elements) {
          try {
            const urn = (e.updateMetadata && e.updateMetadata.urn) || "";
            if (!urn) continue;
            const m = urn.match(/activity[:-](\d{10,})/);
            const activityId = m ? m[1] : urn;
            const text = (e.commentary && e.commentary.text && e.commentary.text.text) || "";
            if (!text) continue;
            const counts = (e.socialDetail && e.socialDetail.totalSocialActivityCounts) || {};
            r.posts.push({
              externalPostId: activityId,
              postUrl: "https://www.linkedin.com/feed/update/urn:li:activity:" + activityId + "/",
              postTextSnippet: text.slice(0, 280),
              hasMedia: !!e.content,
              publishedAtUtc: new Date().toISOString(),
              likeCount: Number(counts.numLikes || 0),
              commentCount: Number(counts.numComments || 0),
              shareCount: Number(counts.numShares || 0),
              rawPayload: null
            });
          } catch (ee) {}
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

function twitterScrapeIIFE(clients) {
  return (async function () {
    function getCookie(name) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    const ct0 = getCookie("ct0");
    const BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
    const headers = {
      "Authorization": "Bearer " + BEARER,
      "x-csrf-token": ct0,
      "x-twitter-active-user": "yes",
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-client-language": "en"
    };
    const results = [];
    for (const c of clients) {
      const r = { clientId: c.id, connectionId: c.twitter.connectionId, platform: "TWITTER", posts: [] };
      try {
        const url =
          "/i/api/1.1/statuses/user_timeline.json?screen_name=" + encodeURIComponent(c.twitter.handle) +
          "&count=50&include_rts=false&tweet_mode=extended";
        const tRes = await fetch(url, { headers: headers, credentials: "include", redirect: "manual" });
        if (!tRes.ok) { r.error = "user_timeline HTTP " + tRes.status; results.push(r); continue; }
        let tweets;
        try { tweets = await tRes.json(); } catch (e) { r.error = "body not JSON"; results.push(r); continue; }
        if (!Array.isArray(tweets)) { r.error = "non-array response (likely auth/anti-bot)"; results.push(r); continue; }
        for (const t of tweets) {
          if (!t.id_str) continue;
          const text = t.full_text || t.text || "";
          const hasMedia = !!(t.entities && t.entities.media && t.entities.media.length);
          r.posts.push({
            externalPostId: t.id_str,
            postUrl: "https://x.com/" + c.twitter.handle + "/status/" + t.id_str,
            postTextSnippet: text.slice(0, 280),
            hasMedia: hasMedia,
            publishedAtUtc: t.created_at ? new Date(t.created_at).toISOString() : new Date().toISOString(),
            likeCount: Number(t.favorite_count || 0),
            commentCount: Number(t.reply_count || 0),
            shareCount: Number(t.retweet_count || 0),
            viewCount: 0,
            rawPayload: null
          });
        }
      } catch (e) {
        r.error = "exception: " + ((e && e.message) || String(e)).slice(0, 200);
      }
      results.push(r);
      await new Promise(function (res) { setTimeout(res, 200); });
    }
    return results;
  })();
}

async function scrapeInTab(tabId, scrapeFunc, clients) {
  try {
    const exec = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: scrapeFunc,
      args: [clients]
    });
    return (exec && exec[0] && exec[0].result) || [];
  } catch (e) {
    return clients.map(function (c) {
      return {
        clientId: c.id,
        connectionId: (c.linkedin && c.linkedin.connectionId) || (c.twitter && c.twitter.connectionId) || "?",
        platform: c.linkedin ? "LINKEDIN" : "TWITTER",
        posts: [],
        error: "executeScript: " + ((e && e.message) || String(e)).slice(0, 120)
      };
    });
  }
}

async function ingest(origin, results) {
  if (!results.length) return { totalUpserted: 0, totalAttempts: 0, failed: 0 };
  const r = await fetch(origin + "/api/extension/ingest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ results: results, source: "extension-v0.10" })
  });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || !j.success) throw new Error((j && j.error) || "rejected");
  return j.data || { totalUpserted: 0, totalAttempts: 0, failed: 0 };
}

async function runFullSync(opts) {
  const origin = (opts && opts.origin) || "https://social.gershoncrm.com";
  const onProgress = (opts && opts.onProgress) || function () {};
  const runLog = [];
  const runStarted = Date.now();
  const cidFilter = (opts && opts.clientIdFilter) || null;
  runLog.push({ at: runStarted, step: "run:start", detail: { origin: origin, version: chrome.runtime.getManifest().version, clientIdFilter: cidFilter } });

  // Fetch the client list FIRST so we know which platforms we actually
  // need to capture cookies for. Otherwise we'd always open LinkedIn AND
  // X tabs even when the targeted client only has one of them — wasteful
  // and confusing ('Cookie capture failed for: LINKEDIN' when the client
  // never had a LinkedIn link to sync).
  onProgress("Fetching client list…", "info");
  let clients;
  try {
    clients = await fetchClients(origin);
  } catch (e2) {
    runLog.push({ at: Date.now(), step: "fetchClients:FAILED", detail: { error: (e2 && e2.message) || String(e2) } });
    return { ok: false, totalUpserted: 0, totalFailed: 0, accountCount: 0, badPlatforms: [], ingestErrors: ["client-fetch: " + ((e2 && e2.message) || e2)], log: runLog };
  }

  // Determine the relevant set of clients per platform. If clientIdFilter
  // is set, narrow to that one client.
  const liClientsCandidates = clients.filter(function (c) {
    return !!c.linkedin && (!cidFilter || c.id === cidFilter);
  });
  const twClientsCandidates = clients.filter(function (c) {
    return !!c.twitter && (!cidFilter || c.id === cidFilter);
  });

  // Decide which platforms to actually CAPTURE cookies for. Only platforms
  // that have at least one client to scrape.
  const platformsToCapture = PLATFORMS.filter(function (p) {
    if (p.name === "LINKEDIN") return liClientsCandidates.length > 0;
    if (p.name === "TWITTER") return twClientsCandidates.length > 0;
    return false;
  });
  runLog.push({
    at: Date.now(),
    step: "plan",
    detail: {
      totalClients: clients.length,
      liClientsToScrape: liClientsCandidates.length,
      twClientsToScrape: twClientsCandidates.length,
      platformsToCapture: platformsToCapture.map(function (p) { return p.name; }),
      skipped: PLATFORMS
        .filter(function (p) { return !platformsToCapture.find(function (q) { return q.name === p.name; }); })
        .map(function (p) { return p.name + " (no clients in scope)"; }),
    }
  });

  if (platformsToCapture.length === 0) {
    runLog.push({ at: Date.now(), step: "run:nothing-to-do", detail: { reason: cidFilter ? "filtered client has no LinkedIn or X link" : "no clients with any platform link" } });
    return { ok: false, totalUpserted: 0, totalFailed: 0, accountCount: 0, badPlatforms: [], ingestErrors: ["nothing to scrape for this client"], log: runLog };
  }

  onProgress("Opening " + platformsToCapture.map(function (p) { return p.label; }).join(" + ") + " to capture sessions…", "info");
  const captureResults = {};
  for (const p of platformsToCapture) {
    onProgress("Capturing " + p.label + " session…", "info");
    captureResults[p.name] = await captureOne(p, origin, runLog);
  }
  const goodPlatforms = Object.keys(captureResults).filter(function (k) { return captureResults[k].ok; });
  const badPlatforms  = Object.keys(captureResults).filter(function (k) { return !captureResults[k].ok; });
  if (goodPlatforms.length === 0) {
    return { ok: false, totalUpserted: 0, totalFailed: 0, accountCount: 0, badPlatforms: badPlatforms, ingestErrors: ["all cookie captures failed"], log: runLog };
  }

  // Only include clients whose platform actually got captured.
  const liClients = (captureResults.LINKEDIN && captureResults.LINKEDIN.ok) ? liClientsCandidates : [];
  const twClients = (captureResults.TWITTER && captureResults.TWITTER.ok) ? twClientsCandidates : [];

  let totalUpserted = 0;
  let totalFailed = 0;
  const ingestErrors = [];

  if (liClients.length && captureResults.LINKEDIN.tabId) {
    onProgress("Scraping LinkedIn in your browser · " + liClients.length + " companies…", "info");
    const liResults = await scrapeInTab(captureResults.LINKEDIN.tabId, linkedinScrapeIIFE, liClients);
    try {
      const out = await ingest(origin, liResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
    } catch (e3) { ingestErrors.push("LinkedIn: " + ((e3 && e3.message) || e3)); }
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  } else if (captureResults.LINKEDIN && captureResults.LINKEDIN.tabId) {
    try { await chrome.tabs.remove(captureResults.LINKEDIN.tabId); } catch (ee) {}
  }

  if (twClients.length && captureResults.TWITTER.tabId) {
    onProgress("Scraping X in your browser · " + twClients.length + " accounts…", "info");
    const twResults = await scrapeInTab(captureResults.TWITTER.tabId, twitterScrapeIIFE, twClients);
    try {
      const out = await ingest(origin, twResults);
      totalUpserted += out.totalUpserted || 0;
      totalFailed += out.failed || 0;
    } catch (e4) { ingestErrors.push("X: " + ((e4 && e4.message) || e4)); }
    // v0.10.2: leave the X tab open after scrape so Olivier can inspect
    // it. Activate it so it's in the foreground instead of hiding in the
    // background tab strip.
    try { await chrome.tabs.update(captureResults.TWITTER.tabId, { active: true }); } catch (ee) {}
  } else if (captureResults.TWITTER && captureResults.TWITTER.tabId) {
    try { await chrome.tabs.update(captureResults.TWITTER.tabId, { active: true }); } catch (ee) {}
  }

  runLog.push({
    at: Date.now(),
    step: "run:done",
    detail: {
      totalUpserted: totalUpserted,
      totalFailed: totalFailed,
      liClientsScraped: liClients.length,
      twClientsScraped: twClients.length,
      badPlatforms: badPlatforms,
      ingestErrors: ingestErrors,
      durationMs: Date.now() - runStarted,
    }
  });

  const lastRunPayload = {
    at: Date.now(),
    durationMs: Date.now() - runStarted,
    totalUpserted: totalUpserted,
    totalFailed: totalFailed,
    accountCount: liClients.length + twClients.length,
    badPlatforms: badPlatforms,
    ingestErrors: ingestErrors,
    log: runLog,
  };
  await chrome.storage.local.set({ lastAutoSync: lastRunPayload, lastRunDetail: lastRunPayload });

  return {
    ok: true,
    totalUpserted: totalUpserted,
    totalFailed: totalFailed,
    accountCount: liClients.length + twClients.length,
    badPlatforms: badPlatforms,
    ingestErrors: ingestErrors,
    log: runLog,
  };
}

if (typeof self !== "undefined") { self.runFullSync = runFullSync; }
if (typeof window !== "undefined") { window.runFullSync = runFullSync; }
