// Service-worker entry point.
//
// Order matters: gx-token.js wraps fetch, so it runs before anything that
// fetches; gx-linkedin.js replaces the LinkedIn page reader for LinkedIn's new
// layout and gx-collect.js wraps self.runFullSync and the tab calls, so both
// run after background.js (which loads sync-core.js) has defined them.
// gx-personal.js (0.13.3) sends /in/ profile links to their activity page.
// gx-session-watch.js (0.14.0) is the LinkedIn sign-out watchdog; it loads
// before gx-collect.js so its login tab uses the real chrome.tabs.create.
// gx-publish.js (0.15.0) publishes approved posts on LinkedIn + X and keeps the
// X session live (HeroPost replacement); also before gx-collect.js, for the same reason.
// Pointing the manifest here keeps background.js and sync-core.js untouched.
// gx-remote.js (0.19.0) takes collection requests queued by the dashboard; last,
// so it uses gx-collect.js's guarded runFullSync. gx-update.js (0.20.0) reloads the
// extension when its folder holds a newer version and nothing is running.
importScripts("gx-token.js", "background.js", "gx-linkedin.js", "gx-session-watch.js", "gx-publish.js", "gx-collect.js", "gx-personal.js", "gx-remote.js", "gx-update.js");
