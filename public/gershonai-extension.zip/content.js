// Inert stub. v0.1 used a content script; v0.2 is cookie-capture only.
