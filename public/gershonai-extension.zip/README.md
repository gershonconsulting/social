# GershonAI Chrome Extension v0.10.0

## What it does

1. **Manual sync (popup button):** click Sync Now → opens LinkedIn + X in
   background tabs → captures your session cookies → scrapes posts for all
   your client accounts inside those tabs → pushes them to
   social.gershoncrm.com.

2. **Daily auto-sync (new in v0.10.0):** a chrome.alarms fires once a day
   and runs the same flow headlessly. No clicking required as long as Chrome
   is open at some point in the day. Badge shows `…` during sync, `✓` on
   success, `!` on error.

3. **Server fallback:** if Chrome was closed all day and the auto-sync
   didn't fire, social.gershoncrm.com's daily 06:00 UTC cron detects stale
   PlatformConnection.lastSyncAt and pulls fresh data via Phantombuster
   instead.

## Install / reload

1. Open `chrome://extensions/`
2. Enable Developer mode (top right)
3. Click the reload icon on the GershonAI card (or drag-drop the zip if
   not already installed)
4. Pin the icon to the toolbar if you want one-click access

## Files

- `manifest.json` — MV3, permissions: cookies / tabs / storage / scripting / alarms
- `background.js` — service worker, owns the alarm and dispatches sync runs
- `sync-core.js` — shared sync flow (cookie capture → scrape → ingest)
- `popup.js` + `popup.html` — Sync Now button, delegates to background
